package bgu.spl.net.impl.stomp;

public class StompServer {

    public static void main(String[] args) {
        // TODO: implement this
    }
}
